import React from 'react'

function Configs() {
    return (
        <div>Configs</div>
    )
}

export default Configs