import React, { useState } from 'react'

function Faq() {

  return (
    <>
      <h1>Faq</h1>
    </>
  )
}

export default Faq;