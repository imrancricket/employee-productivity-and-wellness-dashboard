import React from 'react'

function Subject() {
  return (
    <div>Subject</div>
  )
}

export default Subject