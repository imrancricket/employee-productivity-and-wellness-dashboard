import React from 'react'

function StudyMaterial() {
  return (
    <div>Study Material</div>
  )
}

export default StudyMaterial;