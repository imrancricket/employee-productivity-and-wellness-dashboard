export const ROUTE_IDS = {
    LOGIN : "qwsdfghjz",
}