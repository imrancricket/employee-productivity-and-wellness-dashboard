import React from 'react'

function Logs() {
  return (
    <div>Logs</div>
  )
}

export default Logs